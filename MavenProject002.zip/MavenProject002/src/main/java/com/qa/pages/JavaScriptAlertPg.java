package com.qa.pages;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import ListnerPackage.BaseClass;

public class JavaScriptAlertPg extends BaseClass {

	public JavaScriptAlertPg() throws IOException {
		super();
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//ul[@id ='treemenu']/li/ul/li[5]/ul/li[5]/a")
	WebElement JavaScriptAlertButton;
	
	@FindBy(xpath = "//div[@class ='panel panel-primary'][2]/div[2]/button")
	WebElement JavaScriptConfirmBox;
	
	@FindBy(xpath = "//div[@class ='panel panel-primary'][3]/div[2]/button")
	WebElement JavaScriptAlertBox;
	
	
	
	public void clickMethodJavaScriptAlertPg() throws InterruptedException {
		
		JavaScriptAlertButton.click();
		Thread.sleep(2000);
	
	}
	
	public void ConfirmBoxAlertHandling() throws InterruptedException {
			
		JavaScriptConfirmBox.click();
		Alert alt = driver.switchTo().alert();
		Thread.sleep(2000);
		alt.accept();
		System.out.println("Clicked Ok to alert");
		
		
	}
	
	public void AlertBoxAlertHandling() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,800)");
		JavaScriptAlertBox.click();
		driver.switchTo().alert().sendKeys("TestAlertMessage");
		Thread.sleep(4000);
		driver.switchTo().alert().accept();
		System.out.println("Clicked Cancel to alert");
		Thread.sleep(3000);
		
		
	}
	
	
	
	

}
