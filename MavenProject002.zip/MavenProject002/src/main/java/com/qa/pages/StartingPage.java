package com.qa.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import ListnerPackage.BaseClass;

public class StartingPage extends BaseClass  {
	
	public StartingPage() throws IOException {
		super();
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[contains(text(),'Selenium Easy')]")
	WebElement pageTitle01;
	
	
	public void pagetitlenameChecking(String pageName) {
		
		String pageTitle = pageTitle01.getText().trim();
		//System.out.println("pageTitle  --> " + pageTitle);
		//Boolean CorrectPgTitle =pageTitle.equalsIgnoreCase(pageName);
		//System.out.println("CorrectPgTitle  --> " + CorrectPgTitle);
		Assert.assertEquals(true, pageTitle.equalsIgnoreCase(pageName), "Page Title is not correct");
		
		
	}
	

	
	

}
