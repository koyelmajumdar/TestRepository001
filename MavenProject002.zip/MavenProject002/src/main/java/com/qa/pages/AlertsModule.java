package com.qa.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



import ListnerPackage.BaseClass;

public class AlertsModule extends BaseClass {

	public AlertsModule() throws IOException {
		super();
		PageFactory.initElements(driver, this);
	}
	

	@FindBy(xpath = "//ul[@id ='treemenu']/li/ul/li[5]/a[contains(text(),'Alerts & Modals')]")
	WebElement AlertModuleObj;
	
	@FindBy(xpath = "//ul[@id ='treemenu']/li/ul/li[5]/ul/li[1]/a")
	WebElement BroostrapAlertObj;
	
	

	public void clickMethodAlertModulePg() throws InterruptedException {
	
	//Dynamic - Explicit Wait (will wait for the specific element with a specified condition. As soon as the element will be accessible, 
		//control will move to next step of code without exhausting the total waiting time. If element will not accessible then it will wait up to provided time 
		//period and then through ElementNot Found Exception. )
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		 WebElement AlertModuleElement = wait.until(ExpectedConditions.visibilityOf(AlertModuleObj));
		 AlertModuleElement.click();
	
	}
	
	
	
	public void clickMethodBroostrapAlert() throws InterruptedException  {
		
		 Thread.sleep(2000); //Static wait
		 BroostrapAlertObj.click();
			
		}
	
	public void JavascriptExecutorScrolling() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,1000)");
		
		Thread.sleep(2000);
		
		
	}
	

	
	
}
