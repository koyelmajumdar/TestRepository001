package com.qa.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ListnerPackage.BaseClass;

public class BroostrapAlertMsgPg extends BaseClass {

	public BroostrapAlertMsgPg() throws IOException {
		super();
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//button[@id = 'autoclosable-btn-success']")
	WebElement AutoScalableSucessMsgButton;
	
	@FindBy(xpath = "//button[@id = 'normal-btn-success']")
	WebElement NormalSuccessMsgButton;
	
	@FindBy(xpath = "//div[@class='alert alert-success alert-normal-success']/button[@class = 'close']")
	WebElement CloseSign;
	
	
	
	public void clickMethodBroostrapAlertMsgPg() throws InterruptedException {
		WebDriverWait wt = new WebDriverWait(driver, 30);
		wt.until(ExpectedConditions.visibilityOf(AutoScalableSucessMsgButton)).click();
		Thread.sleep(6000);
		NormalSuccessMsgButton.click();
		Thread.sleep(2000);
		CloseSign.click();
		
	}
	
	

}
