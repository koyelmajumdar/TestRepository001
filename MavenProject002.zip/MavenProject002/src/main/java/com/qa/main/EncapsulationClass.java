package com.qa.main;

public class EncapsulationClass {
	
	static private int i = 5;
	static private int j = 15;

	public static void main(String[] args) {
			
			System.out.println("The value of i = " + i);
			System.out.println("The value of i = " + j);
			
			EncapsulationClass encs = new EncapsulationClass();
			encs.greater();
			encs.setter();

	}
	

	private void greater() {
		
		System.out.println(this.i);
		System.out.println(this.j);
	}
	
	private void setter() {
		
		this.i=10;
		this.j=20;
		
		System.out.println(i);
		System.out.println(j);
		
	}
	
	


}
