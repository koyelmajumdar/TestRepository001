package com.qa.main;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DynamicTableTraverse {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Home\\eclipse-workspace\\MavenProject002\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS); //Page Load Time out..wait until given time limit to load the page.
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.MILLISECONDS);	//Implicit Wait, Work on entire page element and waiting for each element to load in the page for the given amount of time mention in the code
		driver.get("https://www.seleniumeasy.com/test/");
		
		WebDriverWait wait = new WebDriverWait(driver, 60);
		WebElement NoThanksButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(), 'No, thanks!')]")));
		NoThanksButton.click(); 
		
		
		JavascriptExecutor js = (JavascriptExecutor)driver; //Java Script executor to scroll the windows
		js.executeScript("window.scrollBy(0,1000)");
		
		WebElement StartProcessing = driver.findElement(By.xpath("//a[@id='btn_basic_example']"));
		
			StartProcessing.click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//li[@class='tree-branch']/child::a[contains(text(),'Date pickers')]")).click();
			driver.findElement(By.xpath("//li[@class='tree-branch']/ul[1]/li[1]/a[contains(text(),'Bootstrap Date Picker')]")).click();
			
			WebElement SelectDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id ='datepicker']/child::input[1]")));
			SelectDate.click();
			
			
			String MnthYr = driver.findElement(By.xpath("//div[@class='datepicker-days']/table/thead/tr[2]/th[2]")).getText().trim();
			System.out.println("MnthYr --> " + MnthYr);
			
			String MnthYrFromUser = "January 2022";
			String DateFromUser ="12";
			
			System.out.println("MnthYrFromUser --> " + MnthYrFromUser);
			System.out.println("DateFromUser --> " + DateFromUser);
			
			Thread.sleep(3000);
	
			
	while(true){
		if(MnthYr.equalsIgnoreCase(MnthYrFromUser)) {
				
				List<WebElement> rowlist = driver.findElements(By.xpath("//div[@class='datepicker-days']/table/tbody/tr"));
				System.out.println(rowlist.size());
					for(WebElement wb: rowlist) {
						List<WebElement> collist = wb.findElements(By.tagName("td"));
					
							for(WebElement wc: collist) {
								System.out.println("Class attribute -->" + wc.getAttribute("class"));
								if(wc.getText().equalsIgnoreCase(DateFromUser) && wc.getAttribute("class").equalsIgnoreCase("day")){
									wc.click();
									Thread.sleep(2000);
									driver.close();
									break;
								}
						}
						
					}
				}
			
			else {
				
				driver.findElement(By.xpath("//div[@class='datepicker-days']/table/thead/tr[2]/th[3]")).click();
				MnthYr=driver.findElement(By.xpath("//div[@class='datepicker-days']/table/thead/tr[2]/th[2]")).getText().trim();
				System.out.println("MnthYr within else--> " + MnthYr);
				
			}
		
		
				
	}
	
	
	
	}
	
	

}
