package com.qa.main;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Scanner;


public class RobootClassTest {
	
	
	public static void main(String args[]) throws InterruptedException, IOException, AWTException {
		
		System.out.println("Please enter the number that you want to open: number001");
		
		Scanner sc = new Scanner(System.in);
		int number001 = sc.nextInt();
		
		Robot rc;
		
	switch(number001){
			
	case 1:
		
		
			Process	pc1 = Runtime.getRuntime().exec("Notepad"); //Runtime - to open any process
			Thread.sleep(1000);
			
		
		try {
			rc = new Robot();				//Robot Class to write anything in open window
			rc.keyPress(KeyEvent.VK_K);
			rc.keyPress(KeyEvent.VK_O);
			rc.keyPress(KeyEvent.VK_Y);
			rc.keyPress(KeyEvent.VK_E);
			rc.keyPress(KeyEvent.VK_L);
		} catch (AWTException e) {
		
			e.printStackTrace();
		}
		
		Thread.sleep(3000);
		pc1.destroy();
		break;
		
	case 2:
			
			Process pc2 = Runtime.getRuntime().exec("calc");
			Thread.sleep(2000);
			pc2.destroy();
			
			break;
		
	case 3: 
		
			Process pc3 = Runtime.getRuntime().exec("mspaint");
			Thread.sleep(5000);
			pc3.destroy();
		
			break;
			
	case 4: 
			String wrddoc = "c:\\Program Files (x86)\\Microsoft Office\\Office12\\WINWORD.exe /mOpenPage";
			Process pc4 = Runtime.getRuntime().exec(wrddoc);
			Thread.sleep(4000);
			rc = new Robot();
			rc.keyPress(KeyEvent.VK_H);
			rc.keyPress(KeyEvent.VK_A);
			rc.keyPress(KeyEvent.VK_P);
			Thread.sleep(2000);
			rc.keyPress(KeyEvent.VK_P);
			rc.keyPress(KeyEvent.VK_Y);
			Thread.sleep(4000);
			pc4.destroy();
		
		
			break;
			
	case 5: 
			String exceldoc = "cmd /c start excel.exe";
			Process pc5 = Runtime.getRuntime().exec(exceldoc);
			Thread.sleep(4000);
			rc = new Robot();
			rc.keyPress(KeyEvent.VK_H);
			rc.keyPress(KeyEvent.VK_A);
			rc.keyPress(KeyEvent.VK_P);
			Thread.sleep(2000);
			rc.keyPress(KeyEvent.VK_P);
			rc.keyPress(KeyEvent.VK_Y);
			Thread.sleep(4000);
			pc5.destroy();
		
		
			break;
			
	default: System.out.println("you have selected wrong option");
			
			
		
		}
		
	}

}
