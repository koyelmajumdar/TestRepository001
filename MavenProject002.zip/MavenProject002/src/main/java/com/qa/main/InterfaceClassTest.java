package com.qa.main;

public class InterfaceClassTest implements interfaceA, interfaceB {

	public static void main(String[] args) {
		
		InterfaceClassTest var = new InterfaceClassTest();
		var.interfaceMrthodA();
		var.interfaceMrthodB();
		var.interfaceMrthodC();
		var.interfaceMrthodD();		

	}

	public void interfaceMrthodC() {
		System.out.println("I am within interfaceMrthodC");
		
	}

	public void interfaceMrthodD() {
		System.out.println("I am within interfaceMrthodD");
		
	}

	public void interfaceMrthodA() {
		System.out.println("I am within interfaceMrthodA");
		
	}

	public void interfaceMrthodB() {
		System.out.println("I am within interfaceMrthodB");
		
	}
}
	
	  interface interfaceA{
		
		public void interfaceMrthodA();
		public void interfaceMrthodB();
		
	}
	
	  interface interfaceB{
		
		public void interfaceMrthodC();
		public void interfaceMrthodD();
		
	}



