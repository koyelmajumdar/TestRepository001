package com.qa.main;

import java.awt.Window;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import bsh.engine.ScriptContextEngineView;

public class SeleniumWaitTest {
	
	public static void main (String args[]) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Home\\eclipse-workspace\\MavenProject002\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS); //Page Load Time out..wait until given time limit to load the page.
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.MILLISECONDS);	//Implicit Wait, Work on entire page element and waiting for each element to load in the page for the given amount of time mention in the code
		driver.get("https://www.seleniumeasy.com/test/");
		pageNavigation(driver);
	}
	
	public static void pageNavigation(WebDriver driver1) {
		
	//-----------------------------------  1st way for Explicit wait ----------------------------------------------------------------	
	/*	WebElement NoThanksButton= driver1.findElement(By.xpath("//a[contains(text(), 'No, thanks!')]"));
		
		WebDriverWait wait = new WebDriverWait(driver1, 30);	//Explicit wait, It will wait for specific element until that element will not be accessible for the given time period.
		wait.until(ExpectedConditions.elementToBeClickable(NoThanksButton));
		NoThanksButton.click(); */
		
	//-----------------------------------  2nd way for Explicit wait ----------------------------------------------------------------	
		WebDriverWait wait = new WebDriverWait(driver1, 60);
		WebElement NoThanksButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(), 'No, thanks!')]")));
		NoThanksButton.click(); 
		
		
		JavascriptExecutor js = (JavascriptExecutor)driver1; //Java Script executor to scroll the windows
		js.executeScript("window.scrollBy(0,1000)");
		
		WebElement StartProcessing = driver1.findElement(By.xpath("//a[@id='btn_basic_example']"));
		if(StartProcessing.isDisplayed() ==true) {
			System.out.println("Start Processing is displayed and TC passed");
			StartProcessing.click();
		}
		else {
			System.out.println("Start Processing is not displayed and TC failed");
		}
	
		
	// Fluent Wait
		
		
		Wait<WebDriver> fluwait = new FluentWait<WebDriver>(driver1)
				.withTimeout(30, TimeUnit.SECONDS)
			.pollingEvery(50, TimeUnit.MILLISECONDS)
			.ignoring(Exception.class);
		

		
	/*	WebElement javaScriptAlertTag = wait.until(new Function<WebDriver, WebElement>(){
			
			public WebElement apply(WebDriver driver1 ) {
				return driver1.findElement(By.xpath("//div[@class='list-group']/child::a[contains(text(),'Javascript Alerts')]"));
			}
		});  */
		
		
	}
	

}
