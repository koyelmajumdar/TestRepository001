package com.qa.main;

import java.util.Scanner;

public class ArrayDynamicSizeIncrease {

	public static void main(String[] args) {
	
		System.out.println("Enter the array Length = ");
		Scanner sc = new Scanner(System.in);
		int m= sc.nextInt();
		int[] arr = new int[m];
		System.out.println("Array length is = " + arr.length);
		int i = 0;
	
		
		System.out.println("Enter the numbers --> ");
		for(i = 0; i<m; i++) {
				arr[i]= sc.nextInt();
		}
		
	
		int[] arr1 = new int[m*2];
		System.arraycopy(arr, 0, arr1, 0, i);
		
		for(int j = 0; j<m; j++) {
			System.out.println(arr1[j]);
	} 
		
		System.out.println("Array length is = " + arr1.length);

	}

}
