package com.qa.main;

import java.util.Scanner;

public class ArrayDynamicClass {
	
	public static void main(String args[])	{
		
		
		int initialArrayLength = 2;
		int counter =0;
		int flag = 0;
		
		int[] arr1 = new int[initialArrayLength];
		int[] arr2 = null;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the array Elements \n");
		
		while(true) {
			
			for(int i =counter; i<arr1.length; i++) {
				int getValFromUser =sc.nextInt();
				
					if(getValFromUser==0) {
						arr1[i]=getValFromUser;
							flag = 1;
							break;
					}
					else {
						arr1[i]=getValFromUser;
						counter++;
					}
				}
			
			if(flag==1) 
				break;
		
				arr2 = new int[arr1.length*2];
				System.arraycopy(arr1, 0, arr2, 0, arr1.length);
		
					arr1=arr2;
				}

			
			
			for(int j =0; j<arr1.length; j++) {
				System.out.println(arr1[j]);
		}	
			
	
			System.out.println("Final array length of arr1 is =" + arr1.length);
		
	}
	
	
	

}
