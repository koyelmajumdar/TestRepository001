package com.qa.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.support.PageFactory;

public class ExcelReadWriteTest {

	public static void main(String[] args) throws IOException {
		
		
		
		/*	FileInputStream fs = new FileInputStream("C:\\Users\\Home\\eclipse-workspace\\MavenProject002\\config.properties");
		Properties ps = new Properties();
		ps.load(fs);
		String excelpath = ps.getProperty("excellink");
		System.out.println(excelpath);
		FileInputStream fsexcl = new FileInputStream(excelpath); */
		
		FileInputStream fs = new FileInputStream("C:\\Users\\Home\\Desktop\\TestDataSheet.xlsx");
		Workbook wbf = WorkbookFactory.create(fs);
		Sheet ws = wbf.getSheet("Sheet1");
		
	//Excel Read
		Row r = ws.getRow(1);
		String c = r.getCell(1).getStringCellValue();
		
		System.out.println(c);
	
	//Excel Write
	//	r.createCell(2);
	//	r.getCell(2).setCellValue("Majumdar");
	//	FileOutputStream fo = new FileOutputStream("C:\\Users\\Home\\Desktop\\TestDataSheet.xlsx");
	//	 wbf.write(fo);
		 
		
	//Reading Bulk data from Excel
		
		 for(int i=7; i<ws.getLastRowNum();i++) {
			 String flag = "";
			 for(int j=2; j<ws.getRow(7).getLastCellNum(); j++) {
				
	
				 flag = flag + ws.getRow(i).getCell(j)+ "     ";
				 
				 
			 }
			 
			 System.out.println(flag);
		 }
		
		
		

	}

}
