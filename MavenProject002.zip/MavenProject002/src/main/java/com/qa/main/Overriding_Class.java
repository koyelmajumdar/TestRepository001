package com.qa.main;

public class Overriding_Class {

	public static void main(String[] args) {
		
		overB b = new overB();
		b.methodA();
	}

}

class overA{
	String nm="Koyel";
	public void methodA() {
		System.out.println("Within Class over A");
	}
}

class overB extends overA{
	public void methodA() {
		
		System.out.println("Parent variable -> "+ super.nm);
		super.methodA();
		System.out.println("Within Class over B");
	}
	
}
