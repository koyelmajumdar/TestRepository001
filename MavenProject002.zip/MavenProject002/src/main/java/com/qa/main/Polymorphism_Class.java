package com.qa.main;

public class Polymorphism_Class {
	
	Polymorphism_Class(){
		System.out.println("I am within parent Class Constructor");
	}
	public static void main(String args[]) {
		
		Polymorphism_Class a = new Polymorphism_Class();
		a.polyA(2,3);
		a.polyB();
		overrideClass b =new overrideClass();
		b.polyB();
	}

	//---------------------------Compile Time Polymorphism ---------------------------------------------
	// 2 Methods with different argument/return Type/Access Specifier but same Name ................................
	//within same class Method overloading occurred
	
	public  void polyA() {
		System.out.println("Base Method for Overloading");
	}
	
	public  void polyA(int i, int j) {
		System.out.println("overloaded Method");
		int add = i+j;
		System.out.println(add);
	}

	
	//---------------------------RunTime Polymorphism ---------------------------------------------
	// 2 Methods with same name/argument/return Type/Access Specifier but different Implementation ....................
	//within different class Method overriding occurred
	int numberM =4;
	public void polyB() {

		System.out.println("Base Method for Overriding");
	}
		
}

class overrideClass extends Polymorphism_Class{
	
	overrideClass(){
		System.out.println("Overrided Class Cosntructor");
	}
	
	public void polyB() {
	
		super.polyB();
		System.out.println("Parent Method variable access -> " + super.numberM);
		System.out.println("Overrided Method");
		
	}
	
}
