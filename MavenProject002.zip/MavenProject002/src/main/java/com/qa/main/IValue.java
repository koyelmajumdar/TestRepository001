package com.qa.main;

public class IValue {

	public static void main(String[] args) {
		int i=0;
		
		//System.out.println((++i)+(i++));
		//System.out.println(++i+i++);
		System.out.println("The value of ++i is = ");
		System.out.println(++i);
		System.out.println("The value of i++ is = ");
		System.out.println(i++);
		
		System.out.println("Value of post incremented loop");
		for(i=0; i<10; i++) {
			System.out.println(i++);
		}
		
		System.out.println("Value of pre incremented loop");
		for(i=0; i<10; i++) {
			System.out.println(++i);
		}

	}

}
