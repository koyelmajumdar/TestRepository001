package com.qa.main;

public class HelloPrinting {
	
	public static void main(String args[]) {
		System.out.println("Hello Koyel");
	}

}
