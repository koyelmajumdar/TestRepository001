package com.qa.main;

public abstract class AbstractClassTest {
	
	public static void main(String args[]) {
		
		System.out.println("I am main method");
		ImplementedClass abs = new ImplementedClass();
		abs.absMethod1();
		abs.absMethod2();
		abs.absMethod3();
	}
	
	public abstract void absMethod1();
	public abstract void absMethod2();
	public abstract void absMethod3();
		
	public void implementedM4() {
		System.out.println("I am the implemented method within abstract Class");
	}

}

class ImplementedClass{
	
	public void absMethod1() {
		System.out.println("I am absMethod1 implemented");
	}
	
	public void absMethod2() {
		System.out.println("I am absMethod2 implemented");
	}
	
	public void absMethod3() {
		System.out.println("I am absMethod3 implemented");
	}
}
