package com.qa.main;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.htmlunit.HtmlUnitDriver;

//HTMLUnitDriver : Will perform all the action in a web page without opening the GUI interface.
/*Advantages: 
 	1. Faster Execution as Processor need not to handle the GUI interface opening and processing
 	2. We can open other task in browser while Script is taking care of execution
 	3. Limited set up required: in system where we cannot installed browser, suppose server - we can use this headless browser testing without the browser installation.
 */


public class HeadLessBrowserTesting {

	public static void main(String[] args) throws InterruptedException {
		
		HtmlUnitDriver driver = new HtmlUnitDriver(true);
		driver.setJavascriptEnabled(false);
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		
		
		
	
	}

}
