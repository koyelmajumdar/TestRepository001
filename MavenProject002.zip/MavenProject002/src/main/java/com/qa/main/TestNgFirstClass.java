package com.qa.main;

import org.testng.annotations.Test;

public class TestNgFirstClass {

		@Test
		public void testCase1() {
			System.out.println("Hi Koyel..I know this is your first TestNg Class");
		}
}
