package com.qa.main;

public class ExceptionClassTest {
	
	public static void main(String atgs[]) throws Exception {
		
	try {	
		int c =  10/0;
		System.out.println(c);
	}
	catch (Exception e) {
		e.printStackTrace();
	}
		System.out.println("After Exception code");
		
//-------------------------------------------------------------------------------------------------	
		
	try {	
		int c =  10/0;
		System.out.println(c);
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	finally {
		System.out.println("Within finally Block");
	}
		System.out.println("After Exception code");
		

		
		
//-------------------------------------------------------------------------------------------------	
		
		throw new Exception("Single throw statement");
		

//-------------------------------------------------------------------------------------------------	
	/*	try {
		int p = 12/0;
		System.out.println(p);
		}
		catch(ArithmeticException e1){
			throw new Exception("Number is not divided by 0");
			
		}
		
//-------------------------------------------------------------------------------------------------	
		
		try {
		int n = 7/0;
		System.out.println(n);
		}
		catch(ArithmeticException e1){
			throw(e1);
			
		}
		
		System.out.println("After Exception code n");
		
//-------------------------------------------------------------------------------------------------		
		int m = 5/0;
		System.out.println(m);
		
		System.out.println("After Exception code m"); */
		
		
	}
	
	

	

}
