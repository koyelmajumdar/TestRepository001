package com.qa.main;

public class StringReverse {

	public static void main(String[] args) {
		String Name = "Mrs. Koyel Majumar";
		
		String[] arr1 = new String[3];
		arr1=Name.split(" ");
		String Flag = "";
		for(int i=2; i>=0; i--) {
			
			Flag = Flag+ arr1[i] + " ";
			
		}
		System.out.println(Flag);
	}

}
