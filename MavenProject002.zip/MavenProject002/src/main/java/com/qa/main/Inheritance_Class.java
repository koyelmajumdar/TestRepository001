package com.qa.main;

public class Inheritance_Class {

	public static void main(String[] args) {
		
		E obje = new E();
		obje.methodA();
		obje.methodB();
		obje.methodD();
		obje.methodE();

	}
	
			
	}


class A {
	public void methodA() {
		System.out.println("I am within Methos A");
	}
	
}

class B extends A {
	public void methodB() {
		System.out.println("I am within Methos B");
	}
	
}

class D extends B {
	public void methodD() {
		System.out.println("I am within Methos D");
	}
	
}

class E extends D {
	public void methodE() {
		System.out.println("I am within Methos E");
	}
	
}