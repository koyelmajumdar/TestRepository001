package Collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;


public class RemoveDuplicatefromArrayList {
	
	public static void main(String args[]) {
		
	//Removing Duplicate from ArrayList
		
		ArrayList<Object> arr1 = new ArrayList<Object>(Arrays.asList(1,5,6,4,8,7,5,4,2,1,3));
	//HashSet<Object> newHashset = new HashSet<Object>(arr1); // with sorted
		LinkedHashSet<Object> newHashset = new LinkedHashSet<Object>(arr1); //without sorted
		
		ArrayList<Object> arr2 = new ArrayList<Object>(newHashset);
	
		
		System.out.println(arr2);
		System.out.println(arr2.size());
		
		
		
		
		//Removing Duplicate from ArrayList using stream
		ArrayList<Object> arr3 = new ArrayList<Object>(Arrays.asList(1,5,6,4,8,7,5,4,2,1,3));
	//	List<Object> uniqueList = arr3.stream.distinct.collect(collectors.toList());
		//System.out.println(uniqueList);
		
		
	}
	
	
			

}
