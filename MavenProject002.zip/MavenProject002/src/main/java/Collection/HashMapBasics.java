package Collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class HashMapBasics {
	public static void main(String args[]) {
		HashMap<String, String> mapvar = new HashMap<String, String>();
	//Adding value in HashMap	
		mapvar.put("Name", "Koyel");
		mapvar.put("Surname", "Majumdar");
		mapvar.put("NickName", "Mum");
		mapvar.put("Hobby", "Trekking");
		mapvar.put("Friend", "None");
		
		System.out.println(mapvar);
		
	// Accessing element with Key value	
		System.out.println(mapvar.get("Name"));
		
		mapvar.remove("Hobby");
		
	//Iterating Map: Iterator over Key
		Iterator<String> it = mapvar.keySet().iterator();
		while(it.hasNext()) {
			String key = it.next();
			String value = mapvar.get(key);
			System.out.println("Key -->" + key +"  "+ "Value -->" + value);
		}
		
	//Iterating Map: Iterator over (pair) EntrySet	
		Iterator<Entry<String, String>> it1 = mapvar.entrySet().iterator();
		while(it1.hasNext()) {
			Object pair = it1.next();
			System.out.println(pair);
		}
		
	}

}
