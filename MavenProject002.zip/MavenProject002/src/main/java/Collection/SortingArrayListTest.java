package Collection;

import java.util.ArrayList;
import java.util.Arrays;

public class SortingArrayListTest {

	public static void main(String[] args) {
		ArrayList<Object> aar1 = new ArrayList<Object>(Arrays.asList("A", "F", "I", "D", "E"));
		ArrayList<Object> aar2 = new ArrayList<Object>(Arrays.asList("A", "F", "I", "D", "E"));
		ArrayList<Object> aar3 = new ArrayList<Object>(Arrays.asList("A", "F", "I", "D", "C"));
		
	//Sorting
		aar1.sort(null);
		System.out.println(aar1);
		
		aar2.sort(null);
		System.out.println(aar2);
	
	//Comparing 2 arrayLists	
		System.out.println(aar1.equals(aar2));
		System.out.println(aar1.equals(aar3));
		
		
		aar3.removeAll(aar1);	//Removing the duplicate element and returning unique element of aar3
		System.out.println(aar3);
		
		ArrayList<Object> aar4 = new ArrayList<Object>(Arrays.asList("A", "F", "I", "D", "E"));
		ArrayList<Object> aar5 = new ArrayList<Object>(Arrays.asList("A", "F", "I", "D", "E"));
		
		aar4.retainAll(aar5);		//Returning only matching element of aar1
		System.out.println(aar4);
	}

}
