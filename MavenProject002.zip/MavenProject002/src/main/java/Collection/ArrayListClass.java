package Collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class ArrayListClass {
	public static void main(String args[]) {
		
		ArrayList<Object> arrlst = new ArrayList<Object>();
		
		//System.out.println(arrlst.size());
		
	/*	System.out.println("Please Enter the names");
		Scanner sc= new Scanner(System.in);
		for(int i=0;i<5;i++) {
			
			arrlst.add(i, sc.next());
		}
		
		System.out.println(arrlst); */
		
//Accessing ArrayList element with generic for loop
		
		System.out.println("Accessing ArrayList element with generic for loop");	
		arrlst.clear();
		arrlst.add("Emi");
		arrlst.add("Toy");
		arrlst.add("Piyal");
		arrlst.add("Tony");
		for(int i=0;i<arrlst.size();i++) {
				
			System.out.println(arrlst.get(i));
			
			
				}
		
	//Accessing ArrayList element with for each loop
		
			System.out.println("Accessing ArrayList element with for each loop");	
			arrlst.clear();
			arrlst.add("Neha");
			arrlst.add("Tuli");
			arrlst.add("Evan");
			arrlst.add("Rana");
			
		for(Object s: arrlst) {
				
			System.out.println(s);
				}
		
		
		
		
		
		
	//Accessing ArrayList element with iterator
		
		System.out.println("Accessing ArrayList element with Iterator");	
		ArrayList<Object> arr1= new ArrayList<Object>(Arrays.asList("Todd", "Eva", "Carrol", "Devid", "Ema"));
		
		Iterator<Object> it = arr1.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
	//Accessing ArrayList element with lambda expression
	//	ArrayList<Integer> arr2 = new ArrayList<Integer>(Arrays.asList(45,65,85,7,36));
	//	arr2.stream().forEach(el->System.out.println(el));

	

	}
	
	

}
