package Collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class SynchronizedArrayListTest {

	public static void main(String[] args) {
		
	//__________________________________________________________________ 1st way ______________________________________________________
		
	//Converting an ArrayList as ThreadSafe array List using Synchronization
		
		List<Object> arrylst = Collections.synchronizedList(new ArrayList<Object>());
		arrylst.add("Java");
		arrylst.add("Python");
		arrylst.add("Ruby");
		arrylst.add("C++");
		
		System.out.println("arrayList contains -->  " + arrylst);
		System.out.println("Size of arrayList is -->  " + arrylst.size());
		
	// For addition we need not to mention explicit synchronization
		
		arrylst.add(7);
		System.out.println("After adding 7 in arraylist --> " + arrylst);
		System.out.println("Size of arrayList after adding 7 -->  " + arrylst.size());
		
		
	// for Iterating the array List we need to use explicit	Synchronization
		synchronized (arrylst) {
			Iterator it = arrylst.iterator();
			while(it.hasNext()) {
				System.out.println(it.next());
			}
		}
		
		
		//__________________________________________________________________ 2nd way ______________________________________________________
		
		CopyOnWriteArrayList<Object> arrlst2 = new CopyOnWriteArrayList<Object>(); //Already Synchronized, Thread safe, No need to mention Synchronized explicitly.
		
		arrlst2.add("Koyel");
		arrlst2.add("Majumdar");
		
		Iterator<Object> it1 = arrlst2.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
		
		
		}
		


	

	
	}


