package Collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;

public class ArrayListDiffMethods {
	
	public static void main(String args[]) {
		
		ArrayList<Object> arraylst = new ArrayList<Object>();
	
	//Adding object in ArrayList
		arraylst.add("add1");
		arraylst.add("add2");
		arraylst.add("add3");
		arraylst.add("add4");
		arraylst.add("add5");
		arraylst.add("add6");
		arraylst.add("add7");
		arraylst.add("add8");
		arraylst.add("add9");
		arraylst.add("add10");
		
		System.out.println("-------------------------------------------");
		System.out.println(arraylst);
		System.out.println("-------------------------------------------");
		
	//Printing all value with Iterator
		System.out.println("-------------------------------------------");
		System.out.println("All ArrayList element after addition");
		System.out.println("-------------------------------------------");
		Iterator it = arraylst.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	//Removing value from list -> add3
		arraylst.remove(2);
		System.out.println("-------------------------------------------");
		System.out.println("All ArrayList element after deletion of specific element");
		System.out.println("-------------------------------------------");
		for(Object s: arraylst) {
			System.out.println(s);
		}
		arraylst.remove("add5");
		System.out.println(arraylst);
		
	//Cloning the arrayList
		System.out.println("-------------------------------------------");
		System.out.println("All ArrayList element after cloning to new ArrayList");
		System.out.println("-------------------------------------------");
		ArrayList<Object> arr2 = (ArrayList<Object>) arraylst.clone();
		System.out.println(arr2);
		
		
	//Merge 1 arrayList element to other
		System.out.println("-------------------------------------------");
		System.out.println("Margering 1 ArrayList element to other ArrayList elements");
		System.out.println("-------------------------------------------");
		ArrayList<String> arr3 = new ArrayList<String>(Arrays.asList("Nandini", "Palash", "Pihu", "Nilanjan", "Pihu", "Pihu"));
		arraylst.addAll(arr3);
		System.out.println(arraylst);
		System.out.println("-------------------------------------------");
		System.out.println("Removing arrayList arr3 elements from arraylst");
		System.out.println("-------------------------------------------");
		arraylst.removeAll(arr3);
		System.out.println(arraylst);
		System.out.println("-------------------------------------------");
		System.out.println("Margering 1 ArrayList element to other ArrayList elements -> after a specific element");
		System.out.println("-------------------------------------------");
		arraylst.addAll(5, arr3);
		System.out.println(arraylst);
	
	//To check arrayList contains any specific element
		System.out.println("-------------------------------------------");
		System.out.println("To check arrayList contains any specific element");
		System.out.println("-------------------------------------------");
		Boolean containvariable = arraylst.contains("add2");
	
		System.out.println(containvariable);
		
	//To find index of any specific element
		System.out.println("-------------------------------------------");
		System.out.println("To find index of any specific element");
		System.out.println("-------------------------------------------");
		System.out.println(arraylst.indexOf("add2"));
		
	//Getting Latest element if there is repetitive element
		System.out.println("-------------------------------------------");
		System.out.println("Getting Latest element if there is repetitive element");
		System.out.println("-------------------------------------------");
		ArrayList<String> arr4 = new ArrayList<String>(Arrays.asList("Nandini", "Palash", "Pihu", "Nilanjan", "Pihu", "Pihu"));
		System.out.println(arr4.lastIndexOf("Pihu"));
		System.out.println("-------------------------------------------");
		System.out.println("Getting Specific elements if there is repetitive element");
		System.out.println("-------------------------------------------");
		arr4.retainAll(Collections.singleton("Pihu"));
		System.out.println(arr4);
		
		
	//Getting Sublist from an ArrayList
		System.out.println("-------------------------------------------");
		System.out.println("Getting Sublist from an ArrayList");
		System.out.println("-------------------------------------------");
		ArrayList<String> arr5 = new ArrayList<String>(Arrays.asList("Nandini", "Palash", "Pihu", "Nilanjan", "Pihu", "Pihu"));
		System.out.println(arr5.subList(1, 4));
		
		
	//Getting element based on condition
	/*	System.out.println("Getting element based on condition");
		ArrayList<Integer> arr6 = new ArrayList<Integer>(Arrays.asList(10,55, 22, 36, 3));
		arr6.removeIf(num->num%2==0);
		System.out.println(arr6); */
		
		
	//Clearing entire arrayList
		System.out.println("-------------------------------------------");
		System.out.println("Clearing entire arrayList");
		System.out.println("-------------------------------------------");
		ArrayList<Integer> arr6 = new ArrayList<Integer>(Arrays.asList(10,55, 22, 36, 3));
		System.out.println("Before Clearing entire arrayList");
		System.out.println(arr6);
		arr6.clear();
		System.out.println("After Clearing entire arrayList");
		System.out.println(arr6);
		
	}

}
