package ListnerPackage;

import java.io.File;
import java.io.IOException;

import javax.swing.plaf.FileChooserUI;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

public class TakeScreenShotMethodClass extends BaseClass {
	
	public TakeScreenShotMethodClass() throws IOException {
		super();
		}

	public void TakeScreenShotMethod(String MethodName) throws IOException {
		TakesScreenshot takescreen = (TakesScreenshot)driver;
		File sourceFile = takescreen.getScreenshotAs(OutputType.FILE);
	
		//File sourceFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(sourceFile, new File("C:\\Users\\Home\\eclipse-workspace\\MavenProject002\\ScreenShot\\" + MethodName+ ".PNG"));
		
	}

}
