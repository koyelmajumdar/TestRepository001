package ListnerPackage;

import java.io.IOException;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class CustomListenerForTakingScreenShot extends TakeScreenShotMethodClass implements ITestListener {
	
	public CustomListenerForTakingScreenShot() throws IOException {
		super();
		
	}

	public void onTestFailure(ITestResult results) {
		System.out.println("TC Failed");
		try {
			TakeScreenShotMethod(results.getMethod().getMethodName());
		} catch (IOException e) {
				e.printStackTrace();
		}
	}

}
