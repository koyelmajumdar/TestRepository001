	package com.qa.test;

	import java.io.IOException;

	import org.testng.Assert;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeMethod;

	import org.testng.annotations.Test;

	import com.qa.pages.StartingPage;

	import ListnerPackage.BaseClass;

import ListnerPackage.retryAnalyzerUtilityClass;

public class RetryOnTestFailureTestClass extends BaseClass {
	
			StartingPage SP;
		
		public RetryOnTestFailureTestClass() throws IOException {
			super();
			}
		
	//	@BeforeMethod
		public void setup() throws InterruptedException {
			initialization();
			System.out.println("Within setUp");
			Thread.sleep(2000);
		}
		
		
		
		@Test(retryAnalyzer = retryAnalyzerUtilityClass.class)
		public void TestCase1() throws IOException {
			System.out.println("Within TestCase1");
			Assert.assertEquals(false, true);
			
		}
		
		@Test (retryAnalyzer = retryAnalyzerUtilityClass.class)
		public void TestCase2() throws IOException {
			System.out.println("Within TestCase2");
			Assert.assertEquals(true, false);
			
		}
		
		@Test (retryAnalyzer = retryAnalyzerUtilityClass.class)
		public void TestCase3() throws IOException {
			System.out.println("Within TestCase3");
			Assert.assertEquals(true, true);
			
		}
		
	//	@AfterMethod
		public void tearDown() {
			System.out.println("Within tearDown");
			driver.close();
		}
		

	}



