package com.qa.test;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import com.qa.pages.AlertsModule;
import com.qa.pages.BroostrapAlertMsgPg;
import com.qa.pages.JavaScriptAlertPg;

import ListnerPackage.BaseClass;

public class SeleniumWaitsClass extends BaseClass {
	
	AlertsModule AMP;
	BroostrapAlertMsgPg BSAP;
	JavaScriptAlertPg JSAP;
	
	public SeleniumWaitsClass() throws IOException {
		super();
		
	}

	@BeforeMethod
	public void setup() {
		initialization();
	}
	
	@Test(enabled=false)
	public void AlertModulePgTC() throws IOException, InterruptedException {
		AMP = new AlertsModule();
		AMP.clickMethodAlertModulePg();
	}
	
	@Test(enabled=false)
	public void BroostrapAlertMsgPgTC() throws IOException, InterruptedException {
		AMP = new AlertsModule();
		AMP.clickMethodAlertModulePg();
		AMP.clickMethodBroostrapAlert();
		BSAP = new BroostrapAlertMsgPg();
		BSAP.clickMethodBroostrapAlertMsgPg();
		Thread.sleep(2000);
			
	}
	
	@Test(enabled=false)
	public void JavaScriptConfirmBoxTC() throws IOException, InterruptedException {
		AMP = new AlertsModule();
		AMP.clickMethodAlertModulePg();
		AMP.JavascriptExecutorScrolling();
		
		JSAP = new JavaScriptAlertPg();
		JSAP.clickMethodJavaScriptAlertPg();
		JSAP.ConfirmBoxAlertHandling();
		
			
	}
	
	
	@Test
	public void JavaScriptAlertHanlingTC() throws IOException, InterruptedException {
		AMP = new AlertsModule();
		AMP.clickMethodAlertModulePg();
		AMP.JavascriptExecutorScrolling();
		
		JSAP = new JavaScriptAlertPg();
		JSAP.clickMethodJavaScriptAlertPg();
		JSAP.AlertBoxAlertHandling();
		
			
	}
	
	
	@AfterMethod(enabled=false)
	public void tearDown() {
		driver.close();
	}

}
